/* Jennifer Sullivan
 Program 1 Hello Shell
 CSCI - 4547 - 02
 August 30, 2017
 */

#include "tools.hpp"

int main(int argc, const char * argv[]) {
    
    ofstream myOut;
    myOut.open( "P1_Sullivan.txt", ios::out | ios::app);
    
    for (int x = 0; x<argc; x++){
        
        if (x==0){
            myOut << "-----------------------------------" << endl;
            cout << "-----------------------------------" << endl;
            myOut << "command" << " "  << argv[x] << endl;
            cout << "command" << " "  << argv[x] << endl;
        }
        if (*argv[x] == '-' ) {
             myOut << "switch" << " " << argv[x] << endl;
             cout << "switch" << " " << argv[x] << endl;
        }
        else{
            myOut << "argument" << " " << argv[x] << endl;
            cout << "argument" << " " << argv[x] << endl;
        }
    }
    
    return 0;
}

//comments
/*
 
 For test f there is commands and arguments only no switches and for argument e there is a switch statement as well as commands and arguments.
 Also test e is what created the mytemp.txt file and placed everything from P1 into it and gave it the argument "CSCI 6657" and deals only with arguments that are .html including what was in P1. Meanwhile test f only dealt with all of the .bak and .log files as arguments including what was in P1.

*/
